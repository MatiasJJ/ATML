Kai Puolamäki 10.5.2020


aktia.csv Race results from the Aktia maantiejuoksucup 2018-2019.

weather.csv Weather data from FMI, Helsinki-Vantaan lentokenttä, loaded via
https://www.ilmatieteenlaitos.fi/havaintojen-lataus#!/
